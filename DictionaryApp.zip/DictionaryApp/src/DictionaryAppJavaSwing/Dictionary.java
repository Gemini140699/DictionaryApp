package DictionaryAppJavaSwing;

import java.util.ArrayList;

public class Dictionary {

    // TODO: Mảng arrayList lưu trữ Word

    protected static ArrayList<Word> words = new ArrayList<Word>();
}
